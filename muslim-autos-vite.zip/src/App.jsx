import React from 'react'
export default function App(){return <div style={{padding:20,fontFamily:'sans-serif'}}><h1>Muslim Autos</h1><p>Starter ready for Vercel. Run <code>npm i</code> then <code>npm run dev</code> locally, or deploy on Vercel with build= vite and output= dist.</p></div>}
